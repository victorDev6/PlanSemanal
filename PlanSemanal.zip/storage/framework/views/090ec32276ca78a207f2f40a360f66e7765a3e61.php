<?php $__env->startSection('title', 'Menu'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center mt-5">

            <div class="col-12 d-flex justify-content-center">
                <img src="<?php echo e(asset('img/icatech-imagen.png')); ?>" class="img-fluid">
            </div>

            <div class="col-12 d-flex justify-content-center mt-4">
                <h2><strong>Registro de actividades semanales</strong></h2>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\actividades\resources\views/home.blade.php ENDPATH**/ ?>
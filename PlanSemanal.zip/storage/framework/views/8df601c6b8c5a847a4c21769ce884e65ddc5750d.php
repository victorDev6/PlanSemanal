<!DOCTYPE HTML>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>REPORTE SEMANAL</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(public_path('vendor/bootstrap/3.4.1/bootstrap.min.css')); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        body {
            font-family: sans-serif;
        }

        @page  {
            margin: 110px 40px 110px;
        }

        header {
            position: fixed;
            left: 0px;
            top: -100px;
            right: 0px;
            height: 60px;
            background-color: white;
            color: black;
            text-align: center;
            line-height: 60px;
        }

        header h1 {
            margin: 10px 0;
        }

        header h2 {
            margin: 0 0 10px 0;
        }

        footer {
            position: fixed;
            left: 0px;
            bottom: -90px;
            right: 0px;
            height: 60px;
            background-color: white;
            color: black;
            text-align: center;
        }

        footer .page:after {
            content: counter(page);
        }

        footer table {
            width: 100%;
        }

        footer p {
            text-align: right;
        }

        footer .izq {
            text-align: left;
        }

        img.izquierda {
            float: left;
            width: 300px;
            height: 60px;
        }

        img.izquierdabot {
            float: inline-end;
            width: 450px;
            height: 60px;
        }

        img.derechabot {
            position: absolute;
            left: 700px;
            width: 350px;
            height: 60px;

        }

        img.derecha {
            float: right;
            width: 200px;
            height: 60px;
        }

        div.content {
            margin-top: 60%;
            margin-bottom: 70%;
            margin-right: -25%;
            margin-left: 0%;
        }

    </style>
</head>

<body>
    <header>
        <img class="izquierda" src="<?php echo e(public_path('img/instituto_oficial.png')); ?>">
        <img class="derecha" src="<?php echo e(public_path('img/chiapas.png')); ?>">
        
        <div id="wrapper">
            <div align=center>
                <b>
                    <h6>REPORTE DE ACTIVIDADES
                        <br>INSTITUTO DE CAPACITACIÓN Y
                        <br>VINCULACIÓN TECNOLÓGICA DEL ESTADO DE CHIAPAS
                    </h6>
                    <h6>"2021, Año de la Independencia"</h6>
                </b>
            </div>
        </div>
        <br>
    </header>
    <footer>
        <img class="izquierdabot" src="<?php echo e(public_path('img/franja.png')); ?>">
        <img class="derechabot" src="<?php echo e(public_path('img/icatech-imagen.png')); ?>">
    </footer>

    <br>
    <table class="mt-3" width="100%">
        <tbody>
            <tr>
                <td width="20%"><small>ÓRGANO ADMINISTRATIVO:</small></td>
                <td width="80%"> <small><strong><?php echo e($direccion2[0]->descripcion); ?></strong></small></td>
            </tr>
            <tr>
                <td width="20%"><small>SEMANA DE REFERENCIA:</td>
                <td width="80%"><small><strong><?php echo e($semana); ?></strong></small></td>
            </tr>
            
        </tbody>
    </table>

    
    

    <div class="form-row">
        <?php for($i = 0; $i < 5; $i++): ?>
            <?php if($i == 0): ?> 
                <h4 class="display-1">Lunes</h4>
                <?php if($lunes != null): ?>
                    <table width="100%" class="table table-bordered table-striped table-sm">
                        <thead>
                            <tr>
                                <th scope="col"><small>Fecha</small></th>
                                <th scope="col"><small>Asunto</small></th>
                                <th scope="col"><small>Actividad</small></th>
                                <th scope="col"><small>Estatus</small></th>
                                <th scope="col"><small>Observaciones</small></th>
                                <th scope="col"><small>Tipo</small></th>
                                <th scope="col"><small>Indicaciones</small></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $subAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="7"><strong><small><?php echo e($subArea->descripcion); ?></small></strong></td>
                                </tr>
                                <?php $__currentLoopData = $lunes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($subArea->id == $actividad->area_responsable): ?>
                                        <tr>
                                            <td width="100px"><small><?php echo e($actividad->fecha); ?></small></td>
                                            <td scope="col"><small><?php echo e($actividad->asunto); ?></small></td>
                                            <td scope="col"><small><?php echo e($actividad->actividad); ?></small></td>
                                            <td width="100px"><small><?php echo e($actividad->status); ?></small></td>
                                            <td><small><?php echo e($actividad->observaciones); ?></small></td>
                                            <td width="100px" ><small><?php echo e($actividad->tipo_actividad); ?></small></td>
                                            <td><small><?php echo e($actividad->ind_direccion); ?></small></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="mt-3">
                        <div class="col d-flex justify-content-center">
                            <strong><small>Sin Actividades Registradas</small></strong>
                        </div>
                    </div>
                <?php endif; ?>
            <?php elseif($i == 1): ?>
                <h4 class="display-1">Martes</h4>
                <?php if($martes != null): ?>
                    <table width="100%" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th scope="col"><small>Fecha</small></th>
                                <th scope="col"><small>Asunto</small></th>
                                <th scope="col"><small>Actividad</small></th>
                                <th scope="col"><small>Estatus</small></th>
                                <th scope="col"><small>Observaciones</small></th>
                                <th scope="col"><small>Tipo</small></th>
                                <th scope="col"><small>Indicaciones</small></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $subAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="7"><strong><small><?php echo e($subArea->descripcion); ?></small></strong></td>
                                </tr>
                                <?php $__currentLoopData = $martes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($subArea->id == $actividad->area_responsable): ?>
                                        <tr>
                                            <td width="100px"><small><?php echo e($actividad->fecha); ?></small></td>
                                            <td scope="col"><small><?php echo e($actividad->asunto); ?></small></td>
                                            <td scope="col"><small><?php echo e($actividad->actividad); ?></small></td>
                                            <td width="100px"><small><?php echo e($actividad->status); ?></small></td>
                                            <td><small><?php echo e($actividad->observaciones); ?></small></td>
                                            <td width="100px" ><small><?php echo e($actividad->tipo_actividad); ?></small></td>
                                            <td><small><?php echo e($actividad->ind_direccion); ?></small></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="mt-3">
                        <div class="col d-flex justify-content-center">
                            <strong><small>Sin Actividades Registradas</small></strong>
                        </div>
                    </div>
                <?php endif; ?>
            <?php elseif($i == 2): ?>
                <h4 class="display-1">Miercoles</h4>
                <?php if($miercoles != null): ?>
                    <table width="100%" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th scope="col"><small>Fecha</small></th>
                                <th scope="col"><small>Asunto</small></th>
                                <th scope="col"><small>Actividad</small></th>
                                <th scope="col"><small>Estatus</small></th>
                                <th scope="col"><small>Observaciones</small></th>
                                <th scope="col"><small>Tipo</small></th>
                                <th scope="col"><small>Indicaciones</small></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $subAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="7"><strong><small><?php echo e($subArea->descripcion); ?></small></strong></td>
                                </tr>
                                <?php $__currentLoopData = $miercoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($subArea->id == $actividad->area_responsable): ?>
                                        <tr>
                                            <td width="100px"><small><?php echo e($actividad->fecha); ?></small></td>
                                            <td scope="col"><small><?php echo e($actividad->asunto); ?></small></td>
                                            <td scope="col"><small><?php echo e($actividad->actividad); ?></small></td>
                                            <td width="100px"><small><?php echo e($actividad->status); ?></small></td>
                                            <td><small><?php echo e($actividad->observaciones); ?></small></td>
                                            <td width="100px" ><small><?php echo e($actividad->tipo_actividad); ?></small></td>
                                            <td><small><?php echo e($actividad->ind_direccion); ?></small></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="mt-3">
                        <div class="col d-flex justify-content-center">
                            <strong><small>Sin Actividades Registradas</small></strong>
                        </div>
                    </div>
                <?php endif; ?>
            <?php elseif($i == 3): ?>
                <h4 class="display-1">Jueves</h4>
                <?php if($jueves != null): ?>
                    <table width="100%" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th scope="col"><small>Fecha</small></th>
                                <th scope="col"><small>Asunto</small></th>
                                <th scope="col"><small>Actividad</small></th>
                                <th scope="col"><small>Estatus</small></th>
                                <th scope="col"><small>Observaciones</small></th>
                                <th scope="col"><small>Tipo</small></th>
                                <th scope="col"><small>Indicaciones</small></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $subAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="7"><strong><small><?php echo e($subArea->descripcion); ?></small></strong></td>
                                </tr>
                                <?php $__currentLoopData = $jueves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($subArea->id == $actividad->area_responsable): ?>
                                        <tr>
                                            <td width="100px"><small><?php echo e($actividad->fecha); ?></small></td>
                                            <td scope="col"><small><?php echo e($actividad->asunto); ?></small></td>
                                            <td scope="col"><small><?php echo e($actividad->actividad); ?></small></td>
                                            <td width="100px"><small><?php echo e($actividad->status); ?></small></td>
                                            <td><small><?php echo e($actividad->observaciones); ?></small></td>
                                            <td width="100px" ><small><?php echo e($actividad->tipo_actividad); ?></small></td>
                                            <td><small><?php echo e($actividad->ind_direccion); ?></small></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="mt-3">
                        <div class="col d-flex justify-content-center">
                            <strong><small>Sin Actividades Registradas</small></strong>
                        </div>
                    </div>
                <?php endif; ?>
            <?php elseif($i == 4): ?>
                <h4 class="display-1">Viernes</h4>
                <?php if($viernes != []): ?>
                    <table width="100%" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th scope="col"><small>Fecha</small></th>
                                <th scope="col"><small>Asunto</small></th>
                                <th scope="col"><small>Actividad</small></th>
                                <th scope="col"><small>Estatus</small></th>
                                <th scope="col"><small>Observaciones</small></th>
                                <th scope="col"><small>Tipo</small></th>
                                <th scope="col"><small>Indicaciones</small></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $subAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="7"><strong><small><?php echo e($subArea->descripcion); ?></small></strong></td>
                                </tr>
                                <?php $__currentLoopData = $viernes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($subArea->id == $actividad->area_responsable): ?>
                                        <tr>
                                            <td width="100px"><small><?php echo e($actividad->fecha); ?></small></td>
                                            <td scope="col"><small><?php echo e($actividad->asunto); ?></small></td>
                                            <td scope="col"><small><?php echo e($actividad->actividad); ?></small></td>
                                            <td width="100px"><small><?php echo e($actividad->status); ?></small></td>
                                            <td><small><?php echo e($actividad->observaciones); ?></small></td>
                                            <td width="100px" ><small><?php echo e($actividad->tipo_actividad); ?></small></td>
                                            <td><small><?php echo e($actividad->ind_direccion); ?></small></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="mt-3">
                        <div class="col d-flex justify-content-center">
                            <strong><small>Sin Actividades Registradas</small></strong>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endfor; ?>
    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\PlanSemanal\resources\views/layouts/pdfs/reporteSemanal.blade.php ENDPATH**/ ?>
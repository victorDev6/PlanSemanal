


<?php $__env->startSection('title', 'Validación de Actividades'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .colorTop { 
            background-color: #541533;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                VALIDACIÓN DE ACTIVIDADES POR ÓRGANO ADMINISTRATIVO
            </div>
            <div class="card-body">

                <form action="<?php echo e(route('validacion.inicio')); ?>" method="get">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-2">Órgano Validador</div>
                        <div class="col-4">
                            <select name="organo" class="form-control" id="organo">
                                <option value="<?php echo e($organo[0]->id); ?>"><?php echo e($organo[0]->descripcion); ?></option>
                            </select>
                        </div>
                    </div>
    
                    <div class="row mt-2">
                        <div class="col-2">Órgano Administrativo</div>
                        <div class="col-4">
                            <select name="area" id="area" class="custom-select">
                                <option value="">SELECCIONAR</option>
                                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($administrativo == $area->id ? 'selected' : ''); ?> value="<?php echo e($area->id); ?>"><?php echo e($area->descripcion); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-2">
                            <input class="form-control" type="number" name="semana" id="semana" placeholder="Semana" value="<?php echo e($semana); ?>">
                        </div>
                        <div class="col-2">
                            <select name="actividad2" class="form-control" id="actividad2">
                                <option value="">--SELECCIONAR--</option>
                                <option <?php echo e($actividad2 == 'ACTIVIDAD' ? 'selected' : ''); ?>  value="ACTIVIDAD">ACTIVIDAD</option>
                                <option <?php echo e($actividad2 == 'PERMISO' ? 'selected' : ''); ?> value="PERMISO">PERMISO</option>
                            </select>
                        </div>
                        <div class="col">
                            <button type="submit" class="btn btn-outline-primary">FILTRAR</button>
                        </div>
                    </div>
                </form>

                <div class="row mt-4">

                    <?php if(!$actividades->isEmpty()): ?>
                        <div class="col">
                            <form action="<?php echo e(route('validacion.enviar')); ?>" method="post">
                                <?php echo csrf_field(); ?>
        
                                <input class="d-none" type="text" id="tipo_act" name="tipo_act" value="<?php echo e($actividad2); ?>">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">Fecha</th>
                                            <th scope="col">Asunto</th>
                                            <th scope="col">Área responsable</th>
                                            <th scope="col">Actividad</th>
                                            <th scope="col">Estatus</th>
                                            <th scope="col">Observaciones</th>
                                            <th scope="col">Tipo</th>
                                            <th scope="col">Semana</th>
                                            <th scope="col">Enviado</th>
                                            <th scope="col">Selección</th>
                                        </tr>
                                    </thead>
            
                                    <tbody>
                                        <input id="administrativo" name="administrativo" class="d-none" type="number" value="<?php echo e($administrativo); ?>">
                                        <input id="semana" name="semana" class="d-none" type="number" value="<?php echo e($semana); ?>">

                                        <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td width="100px"><?php echo e($actividad->fecha); ?></td>
                                                <td><?php echo e($actividad->asunto); ?></td>
                                                <td width="200px" ><?php echo e($actividad->descripcion); ?></td>
                                                <td><?php echo e($actividad->actividad); ?></td>
                                                <td width="120px"><?php echo e($actividad->status); ?></td>
                                                <td><?php echo e($actividad->observaciones); ?></td>
                                                <td width="100px" ><?php echo e($actividad->tipo_actividad); ?></td>
                                                <td width="40px"><?php echo e($actividad->semana); ?></td>
                                                <td width="50px">
                                                    <?php if($actividad->fecha_validacion == null): ?>
                                                        NO
                                                    <?php else: ?>
                                                        SI
                                                    <?php endif; ?>
                                                </td>
                                                <td width="40px">
                                                    <?php if($actividad->fecha_validacion == null): ?>
                                                        <div class="custom-control custom-checkbox d-flex justify-content-center">
                                                            <input type="checkbox" value="<?php echo e($actividad->id); ?>" class="custom-control-input settings"
                                                                name="actividades[]" id="check + <?php echo e($actividad->id); ?>">
                                                            <label class="custom-control-label"
                                                                for="check + <?php echo e($actividad->id); ?>"></label>
                                                        </div>
                                                    <?php else: ?>
                                                        No Disponible
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                                
                                    <div class="row">
                                        <div class="col d-flex justify-content-end">
                                            <button type="submit" class="btn btn-primary btn-lg">Enviar a DG</button>
                                        </div>
                                    </div>
                                
                            </form>
                        </div>
                    <?php else: ?>
                        <div class="col text-center mt-5">
                            <h5><strong>Sin Actividades Registradas</strong></h5>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanSemanal\resources\views/layouts/inicioValidacion.blade.php ENDPATH**/ ?>
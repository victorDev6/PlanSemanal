


<?php $__env->startSection('title', 'Plan Semanal'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .colorTop { 
            background-color: #541533;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">PLAN SEMANAL</div>
            <div class="card-body">

                <form action="<?php echo e(route('plan.inicio')); ?>" method="get">
                    <?php echo csrf_field(); ?>

                    
                    <div class="row">
                        <div class="col-3">Ejercicio</div>
                        <div class="col-4">
                            <select id="ejercicio" name="ejercicio" class="form-control">
                                <option <?php echo e($ejercicio == '2021' ? 'selected' : ''); ?> value="2021">2021</option>
                                <option <?php echo e($ejercicio == '2022' ? 'selected' : ''); ?> value="2022">2022</option>
                                <option <?php echo e($ejercicio == '2023' ? 'selected' : ''); ?> value="2023">2023</option>
                                <option <?php echo e($ejercicio == '2024' ? 'selected' : ''); ?> value="2024">2024</option>
                                <option <?php echo e($ejercicio == '2025' ? 'selected' : ''); ?> value="2025">2025</option>
                                <option <?php echo e($ejercicio == '2026' ? 'selected' : ''); ?> value="2026">2026</option>
                                <option <?php echo e($ejercicio == '2027' ? 'selected' : ''); ?> value="2027">2027</option>
                                <option <?php echo e($ejercicio == '2028' ? 'selected' : ''); ?> value="2028">2028</option>
                                <option <?php echo e($ejercicio == '2029' ? 'selected' : ''); ?> value="2029">2029</option>
                                <option <?php echo e($ejercicio == '2030' ? 'selected' : ''); ?> value="2030">2030</option>
                            </select>
                        </div>
                    </div>

                    
                    <div class="row mt-2">
                        <div class="col-3">Mes</div>
                        <div class="col-4">
                            <select name="mes" class="form-control" id="mes">
                                <option value="">SELECCIONAR</option>
                                <option <?php echo e($mes == '01' ? 'selected' : ''); ?> value="01">Enero</option>
                                <option <?php echo e($mes == '02' ? 'selected' : ''); ?> value="02">Febrero</option>
                                <option <?php echo e($mes == '03' ? 'selected' : ''); ?> value="03">Marzo</option>
                                <option <?php echo e($mes == '04' ? 'selected' : ''); ?> value="04">Abril</option>
                                <option <?php echo e($mes == '05' ? 'selected' : ''); ?> value="05">Mayo</option>
                                <option <?php echo e($mes == '06' ? 'selected' : ''); ?> value="06">Junio</option>
                                <option <?php echo e($mes == '07' ? 'selected' : ''); ?> value="07">Julio</option>
                                <option <?php echo e($mes == '08' ? 'selected' : ''); ?> value="08">Agosto</option>
                                <option <?php echo e($mes == '09' ? 'selected' : ''); ?> value="09">Septiembre</option>
                                <option <?php echo e($mes == '10' ? 'selected' : ''); ?> value="10">Octubre</option>
                                <option <?php echo e($mes == '11' ? 'selected' : ''); ?> value="11">Noviembre</option>
                                <option <?php echo e($mes == '12' ? 'selected' : ''); ?> value="12">Diciembre</option>
                            </select>
                        </div>
                    </div>

                    
                    <div class="row mt-2">
                        <div class="col-3">Dirección</div>
                        <div class="col-4">
                            <select name="area" id="area" class="custom-select">
                                <option value="">SELECCIONAR</option>
                                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($area->id == $direccion ? 'selected' : ''); ?> value="<?php echo e($area->id); ?>"><?php echo e($area->descripcion); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col">
                            <input class="form-control" type="number" name="semana" id="semana" placeholder="Semana"
                            value="<?php echo e($semana); ?>">
                        </div>
                        <div class="col">
                            <button type="submit" class="btn btn-outline-primary">FILTRAR</button>
                        </div>
                    </div>
                </form>

                <div class="row mt-4">
                    <div class="col d-flex justify-content-center">
                        <h4><strong>PLAN SEMANAL</strong></h4>
                    </div>
                </div>

                <div class="row">
                    <div class="col">
                        
                        <nav>
                            <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                                <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Lunes</a>
                                <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Martes</a>
                                <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Miercoles</a>
                                <a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#nav-about" role="tab" aria-controls="nav-about" aria-selected="false">Jueves</a>
                                <a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#nav-viernes" role="tab" aria-controls="nav-about" aria-selected="false">Viernes</a>
                            </div>
                        </nav>

                        
                        <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                            
                            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                <?php if($lunes != []): ?>
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">Fecha</th>
                                                <th scope="col">Asunto</th>
                                                <th scope="col">Actividad</th>
                                                <th scope="col">Estatus</th>
                                                <th scope="col">Observaciones</th>
                                                <th scope="col">Tipo</th>
                                                <th scope="col">Indicaciones</th>
                                                <?php if($organo == null): ?>
                                                    <th scope="col">Mostrar</th>
                                                <?php endif; ?>
                                                <th scope="col">Enviar</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $subAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr >
                                                    <td colspan="<?php echo e($organo== null ? '9' : '8'); ?>"><strong><?php echo e($subArea->descripcion); ?></strong></td>
                                                </tr>
                                                <?php $__currentLoopData = $lunes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php if($subArea->id == $actividad->area_responsable): ?>
                                                        <form action="<?php echo e(route('plan.editar',  ['id' => $actividad->id])); ?>" method="post">
                                                            <?php echo csrf_field(); ?>

                                                            <tr>
                                                                <td width="120px"><?php echo e($actividad->fecha); ?></td>
                                                                <td><?php echo e($actividad->asunto); ?></td>
                                                                <td><?php echo e($actividad->actividad); ?></td>
                                                                <td width="120px"><?php echo e($actividad->status); ?></td>
                                                                <td><?php echo e($actividad->observaciones); ?></td>
                                                                <td width="100px" ><?php echo e($actividad->tipo_actividad); ?></td>
                                                                <td>
                                                                    <?php if($organo == null): ?>
                                                                        <input class="form-control" type="text" name="indicaciones"
                                                                        id="indicaciones" placeholder="Indicaciones"
                                                                        value="<?php echo e($actividad->ind_direccion); ?>">
                                                                    <?php else: ?>
                                                                        <?php if($actividad->mostrar == null || str_contains($actividad->mostrar, 'Validador')): ?>
                                                                            <input class="form-control" type="text" name="indicaciones"
                                                                            id="indicaciones" placeholder="Indicaciones"
                                                                            value="<?php echo e($actividad->ind_direccion); ?>">
                                                                        <?php else: ?>
                                                                            <small>Permiso no otorgado</small>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <?php if($organo == null): ?>
                                                                    <td class="pb-0" width="100px">
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input <?php echo e($actividad->mostrar != null ? str_contains($actividad->mostrar, 'Director') ? 'checked' : '' : ''); ?> type="checkbox" 
                                                                            value="Director" class="custom-control-input settings"
                                                                                name="views[]" id="check + <?php echo e($actividad->id); ?>">
                                                                            <label class="custom-control-label"
                                                                                for="check + <?php echo e($actividad->id); ?>"><small>Director</small></label>
                                                                        </div>
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input <?php echo e($actividad->mostrar != null ? str_contains($actividad->mostrar, 'Validador') ? 'checked' : '' : ''); ?> type="checkbox" 
                                                                            value="Validador" class="custom-control-input settings"
                                                                                name="views[]" id="check2 + <?php echo e($actividad->id); ?>">
                                                                            <label class="custom-control-label"
                                                                                for="check2 + <?php echo e($actividad->id); ?>"><small>Validador</small></label>
                                                                        </div>
                                                                    </td>
                                                                <?php endif; ?>
                                                                <td width="80px">
                                                                    <?php if($organo == null): ?>
                                                                        <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                                                                    <?php else: ?>
                                                                        <?php if($actividad->mostrar == null || str_contains($actividad->mostrar, 'Validador')): ?>
                                                                            <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                                                                        <?php else: ?>
                                                                            <small>Permiso no otorgado</small>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="row mt-3">
                                        <div class="col d-flex justify-content-center">
                                            <strong>Sin Actividades registradas</strong>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                                <?php if($martes != []): ?>
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">Fecha</th>
                                                <th scope="col">Asunto</th>
                                                <th scope="col">Actividad</th>
                                                <th scope="col">Estatus</th>
                                                <th scope="col">Observaciones</th>
                                                <th scope="col">Tipo</th>
                                                <th scope="col">Indicaciones</th>
                                                <?php if($organo == null): ?>
                                                    <th scope="col">Mostrar</th>
                                                <?php endif; ?>
                                                <th scope="col">Enviar</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $subAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td colspan="<?php echo e($organo== null ? '9' : '8'); ?>"><strong><?php echo e($subArea->descripcion); ?></strong></td>
                                                </tr>
                                                <?php $__currentLoopData = $martes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php if($subArea->id == $actividad->area_responsable): ?>
                                                        <form action="<?php echo e(route('plan.editar',  ['id' => $actividad->id])); ?>" method="post">
                                                            <?php echo csrf_field(); ?>

                                                            <tr>
                                                                <td width="120px"><?php echo e($actividad->fecha); ?></td>
                                                                <td><?php echo e($actividad->asunto); ?></td>
                                                                <td><?php echo e($actividad->actividad); ?></td>
                                                                <td width="120px"><?php echo e($actividad->status); ?></td>
                                                                <td><?php echo e($actividad->observaciones); ?></td>
                                                                <td width="100px" ><?php echo e($actividad->tipo_actividad); ?></td>
                                                                <td>
                                                                    <?php if($organo == null): ?>
                                                                        <input class="form-control" type="text" name="indicaciones"
                                                                        id="indicaciones" placeholder="Indicaciones"
                                                                        value="<?php echo e($actividad->ind_direccion); ?>">
                                                                    <?php else: ?>
                                                                        <?php if($actividad->mostrar == null || str_contains($actividad->mostrar, 'Validador')): ?>
                                                                            <input class="form-control" type="text" name="indicaciones"
                                                                            id="indicaciones" placeholder="Indicaciones"
                                                                            value="<?php echo e($actividad->ind_direccion); ?>">
                                                                        <?php else: ?>
                                                                            <small>Permiso no otorgado</small>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <?php if($organo == null): ?>
                                                                    <td class="pb-0" width="100px">
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input <?php echo e($actividad->mostrar != null ? str_contains($actividad->mostrar, 'Director') ? 'checked' : '' : ''); ?> type="checkbox" 
                                                                            value="Director" class="custom-control-input settings"
                                                                                name="views[]" id="check + <?php echo e($actividad->id); ?>">
                                                                            <label class="custom-control-label"
                                                                                for="check + <?php echo e($actividad->id); ?>"><small>Director</small></label>
                                                                        </div>
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input <?php echo e($actividad->mostrar != null ? str_contains($actividad->mostrar, 'Validador') ? 'checked' : '' : ''); ?> type="checkbox" 
                                                                            value="Validador" class="custom-control-input settings"
                                                                                name="views[]" id="check2 + <?php echo e($actividad->id); ?>">
                                                                            <label class="custom-control-label"
                                                                                for="check2 + <?php echo e($actividad->id); ?>"><small>Validador</small></label>
                                                                        </div>
                                                                    </td>
                                                                <?php endif; ?>
                                                                <td width="80px">
                                                                    <?php if($organo == null): ?>
                                                                        <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                                                                    <?php else: ?>
                                                                        <?php if($actividad->mostrar == null || str_contains($actividad->mostrar, 'Validador')): ?>
                                                                            <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                                                                        <?php else: ?>
                                                                            <small>Permiso no otorgado</small>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="row mt-3">
                                        <div class="col d-flex justify-content-center">
                                            <strong>Sin Actividades registradas</strong>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                                <?php if($miercoles != []): ?>
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">Fecha</th>
                                                <th scope="col">Asunto</th>
                                                <th scope="col">Actividad</th>
                                                <th scope="col">Estatus</th>
                                                <th scope="col">Observaciones</th>
                                                <th scope="col">Tipo</th>
                                                <th scope="col">Indicaciones</th>
                                                <?php if($organo == null): ?>
                                                    <th scope="col">Mostrar</th>
                                                <?php endif; ?>
                                                <th scope="col">Enviar</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $subAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr >
                                                    <td colspan="<?php echo e($organo== null ? '9' : '8'); ?>"><strong><?php echo e($subArea->descripcion); ?></strong></td>
                                                </tr>
                                                <?php $__currentLoopData = $miercoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php if($subArea->id == $actividad->area_responsable): ?>
                                                        <form action="<?php echo e(route('plan.editar',  ['id' => $actividad->id])); ?>" method="post">
                                                            <?php echo csrf_field(); ?>

                                                            <tr>
                                                                <td width="120px"><?php echo e($actividad->fecha); ?></td>
                                                                <td><?php echo e($actividad->asunto); ?></td>
                                                                <td><?php echo e($actividad->actividad); ?></td>
                                                                <td width="120px"><?php echo e($actividad->status); ?></td>
                                                                <td><?php echo e($actividad->observaciones); ?></td>
                                                                <td width="100px" ><?php echo e($actividad->tipo_actividad); ?></td>
                                                                <td>
                                                                    <?php if($organo == null): ?>
                                                                        <input class="form-control" type="text" name="indicaciones"
                                                                        id="indicaciones" placeholder="Indicaciones"
                                                                        value="<?php echo e($actividad->ind_direccion); ?>">
                                                                    <?php else: ?>
                                                                        <?php if($actividad->mostrar == null || str_contains($actividad->mostrar, 'Validador')): ?>
                                                                            <input class="form-control" type="text" name="indicaciones"
                                                                            id="indicaciones" placeholder="Indicaciones"
                                                                            value="<?php echo e($actividad->ind_direccion); ?>">
                                                                        <?php else: ?>
                                                                            <small>Permiso no otorgado</small>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <?php if($organo == null): ?>
                                                                    <td class="pb-0" width="100px">
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input <?php echo e($actividad->mostrar != null ? str_contains($actividad->mostrar, 'Director') ? 'checked' : '' : ''); ?> type="checkbox" 
                                                                            value="Director" class="custom-control-input settings"
                                                                                name="views[]" id="check + <?php echo e($actividad->id); ?>">
                                                                            <label class="custom-control-label"
                                                                                for="check + <?php echo e($actividad->id); ?>"><small>Director</small></label>
                                                                        </div>
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input <?php echo e($actividad->mostrar != null ? str_contains($actividad->mostrar, 'Validador') ? 'checked' : '' : ''); ?> type="checkbox" 
                                                                            value="Validador" class="custom-control-input settings"
                                                                                name="views[]" id="check2 + <?php echo e($actividad->id); ?>">
                                                                            <label class="custom-control-label"
                                                                                for="check2 + <?php echo e($actividad->id); ?>"><small>Validador</small></label>
                                                                        </div>
                                                                    </td>
                                                                <?php endif; ?>
                                                                <td width="80px">
                                                                    <?php if($organo == null): ?>
                                                                        <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                                                                    <?php else: ?>
                                                                        <?php if($actividad->mostrar == null || str_contains($actividad->mostrar, 'Validador')): ?>
                                                                            <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                                                                        <?php else: ?>
                                                                            <small>Permiso no otorgado</small>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="row mt-3">
                                        <div class="col d-flex justify-content-center">
                                            <strong>Sin Actividades registradas</strong>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="tab-pane fade" id="nav-about" role="tabpanel" aria-labelledby="nav-about-tab">
                                <?php if($jueves != []): ?>
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">Fecha</th>
                                                <th scope="col">Asunto</th>
                                                <th scope="col">Actividad</th>
                                                <th scope="col">Estatus</th>
                                                <th scope="col">Observaciones</th>
                                                <th scope="col">Tipo</th>
                                                <th scope="col">Indicaciones</th>
                                                <?php if($organo == null): ?>
                                                    <th scope="col">Mostrar</th>
                                                <?php endif; ?>
                                                <th scope="col">Enviar</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $subAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr >
                                                    <td colspan="<?php echo e($organo== null ? '9' : '8'); ?>"><strong><?php echo e($subArea->descripcion); ?></strong></td>
                                                </tr>
                                                <?php $__currentLoopData = $jueves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php if($subArea->id == $actividad->area_responsable): ?>
                                                        <form action="<?php echo e(route('plan.editar',  ['id' => $actividad->id])); ?>" method="post">
                                                            <?php echo csrf_field(); ?>

                                                            <tr>
                                                                <td width="120px"><?php echo e($actividad->fecha); ?></td>
                                                                <td><?php echo e($actividad->asunto); ?></td>
                                                                <td><?php echo e($actividad->actividad); ?></td>
                                                                <td width="120px"><?php echo e($actividad->status); ?></td>
                                                                <td><?php echo e($actividad->observaciones); ?></td>
                                                                <td width="100px" ><?php echo e($actividad->tipo_actividad); ?></td>
                                                                <td>
                                                                    <?php if($organo == null): ?>
                                                                        <input class="form-control" type="text" name="indicaciones"
                                                                        id="indicaciones" placeholder="Indicaciones"
                                                                        value="<?php echo e($actividad->ind_direccion); ?>">
                                                                    <?php else: ?>
                                                                        <?php if($actividad->mostrar == null || str_contains($actividad->mostrar, 'Validador')): ?>
                                                                            <input class="form-control" type="text" name="indicaciones"
                                                                            id="indicaciones" placeholder="Indicaciones"
                                                                            value="<?php echo e($actividad->ind_direccion); ?>">
                                                                        <?php else: ?>
                                                                            <small>Permiso no otorgado</small>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <?php if($organo == null): ?>
                                                                    <td class="pb-0" width="100px">
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input <?php echo e($actividad->mostrar != null ? str_contains($actividad->mostrar, 'Director') ? 'checked' : '' : ''); ?> type="checkbox" 
                                                                            value="Director" class="custom-control-input settings"
                                                                                name="views[]" id="check + <?php echo e($actividad->id); ?>">
                                                                            <label class="custom-control-label"
                                                                                for="check + <?php echo e($actividad->id); ?>"><small>Director</small></label>
                                                                        </div>
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input <?php echo e($actividad->mostrar != null ? str_contains($actividad->mostrar, 'Validador') ? 'checked' : '' : ''); ?> type="checkbox" 
                                                                            value="Validador" class="custom-control-input settings"
                                                                                name="views[]" id="check2 + <?php echo e($actividad->id); ?>">
                                                                            <label class="custom-control-label"
                                                                                for="check2 + <?php echo e($actividad->id); ?>"><small>Validador</small></label>
                                                                        </div>
                                                                    </td>
                                                                <?php endif; ?>
                                                                <td width="80px">
                                                                    <?php if($organo == null): ?>
                                                                        <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                                                                    <?php else: ?>
                                                                        <?php if($actividad->mostrar == null || str_contains($actividad->mostrar, 'Validador')): ?>
                                                                            <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                                                                        <?php else: ?>
                                                                            <small>Permiso no otorgado</small>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="row mt-3">
                                        <div class="col d-flex justify-content-center">
                                            <strong>Sin Actividades registradas</strong>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="tab-pane fade" id="nav-viernes" role="tabpanel" aria-labelledby="nav-about-tab">
                                <?php if($viernes != []): ?>
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">Fecha</th>
                                                <th scope="col">Asunto</th>
                                                <th scope="col">Actividad</th>
                                                <th scope="col">Estatus</th>
                                                <th scope="col">Observaciones</th>
                                                <th scope="col">Tipo</th>
                                                <th scope="col">Indicaciones</th>
                                                <?php if($organo == null): ?>
                                                    <th scope="col">Mostrar</th>
                                                <?php endif; ?>
                                                <th scope="col">Enviar</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $subAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr >
                                                    <td colspan="<?php echo e($organo== null ? '9' : '8'); ?>"><strong><?php echo e($subArea->descripcion); ?></strong></td>
                                                </tr>
                                                <?php $__currentLoopData = $viernes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php if($subArea->id == $actividad->area_responsable): ?>
                                                        <form action="<?php echo e(route('plan.editar',  ['id' => $actividad->id])); ?>" method="post">
                                                            <?php echo csrf_field(); ?>

                                                            <tr>
                                                                <td width="120px"><?php echo e($actividad->fecha); ?></td>
                                                                <td><?php echo e($actividad->asunto); ?></td>
                                                                <td><?php echo e($actividad->actividad); ?></td>
                                                                <td width="120px"><?php echo e($actividad->status); ?></td>
                                                                <td><?php echo e($actividad->observaciones); ?></td>
                                                                <td width="100px" ><?php echo e($actividad->tipo_actividad); ?></td>
                                                                <td>
                                                                    <?php if($organo == null): ?>
                                                                        <input class="form-control" type="text" name="indicaciones"
                                                                        id="indicaciones" placeholder="Indicaciones"
                                                                        value="<?php echo e($actividad->ind_direccion); ?>">
                                                                    <?php else: ?>
                                                                        <?php if($actividad->mostrar == null || str_contains($actividad->mostrar, 'Validador')): ?>
                                                                            <input class="form-control" type="text" name="indicaciones"
                                                                            id="indicaciones" placeholder="Indicaciones"
                                                                            value="<?php echo e($actividad->ind_direccion); ?>">
                                                                        <?php else: ?>
                                                                            <small>Permiso no otorgado</small>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <?php if($organo == null): ?>
                                                                    <td class="pb-0" width="100px">
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input <?php echo e($actividad->mostrar != null ? str_contains($actividad->mostrar, 'Director') ? 'checked' : '' : ''); ?> type="checkbox" 
                                                                            value="Director" class="custom-control-input settings"
                                                                                name="views[]" id="check + <?php echo e($actividad->id); ?>">
                                                                            <label class="custom-control-label"
                                                                                for="check + <?php echo e($actividad->id); ?>"><small>Director</small></label>
                                                                        </div>
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input <?php echo e($actividad->mostrar != null ? str_contains($actividad->mostrar, 'Validador') ? 'checked' : '' : ''); ?> type="checkbox" 
                                                                            value="Validador" class="custom-control-input settings"
                                                                                name="views[]" id="check2 + <?php echo e($actividad->id); ?>">
                                                                            <label class="custom-control-label"
                                                                                for="check2 + <?php echo e($actividad->id); ?>"><small>Validador</small></label>
                                                                        </div>
                                                                    </td>
                                                                <?php endif; ?>
                                                                <td width="80px">
                                                                    <?php if($organo == null): ?>
                                                                        <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                                                                    <?php else: ?>
                                                                        <?php if($actividad->mostrar == null || str_contains($actividad->mostrar, 'Validador')): ?>
                                                                            <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                                                                        <?php else: ?>
                                                                            <small>Permiso no otorgado</small>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="row mt-3">
                                        <div class="col d-flex justify-content-center">
                                            <strong>Sin Actividades registradas</strong>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if($lunes !=[] || $martes != [] || $miercoles != [] || $jueves != [] || $viernes != []): ?>
                    <div class="row pr-2 d-flex justify-content-end">
                        <a href="<?php echo e(route('planSemanal.reporte', ['ejercicio' => $ejercicio, 'mes' => $mes, 'direccion' => $direccion, 'semana' => $semana])); ?>">
                            <button type="button" class="btn btn-primary">GENERAR REPORTE</button>
                        </a>
                    </div>
                <?php endif; ?>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanSemanal\resources\views/layouts/inicioPlanSemanal.blade.php ENDPATH**/ ?>
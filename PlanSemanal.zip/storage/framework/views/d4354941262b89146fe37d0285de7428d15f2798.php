


<?php $__env->startSection('title', 'Visto Bueno Actividades'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        

        <?php if(!empty($success)): ?>
            <div class="alert alert-success"> <?php echo e($success); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                VALIDACIÓN DE ACTIVIDADES POR ÓRGANO ADMINISTRATIVO
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('vtoBueno.inicio')); ?>" method="get">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-3">Órgano Validador</div>
                        <div class="col-4">
                            <select name="organo" class="form-control" id="organo">
                                <option value="<?php echo e($organo[0]->id); ?>"><?php echo e($organo[0]->descripcion); ?></option>
                            </select>
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-3">Semana</div>
                        <div class="col-4">
                            <input class="form-control" type="number" name="semana" id="semana" placeholder="Semana"
                                value="<?php echo e($semana); ?>">
                        </div>
                        <div class="col">
                            <button type="submit" class="btn btn-outline-primary">FILTRAR</button>
                        </div>
                    </div>
                </form>

                <div class="row mt-4">
                    <div class="col">
                        <?php if(!$actividades->isEmpty()): ?>
                            <form action="<?php echo e(route('vtoBueno.enviar', ['semana'=>$actividades[0]->semana])); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">Fecha</th>
                                            <th scope="col">Asunto</th>
                                            <th scope="col">Actividad</th>
                                            <th scope="col">Estatus</th>
                                            <th scope="col">Observaciones</th>
                                            <th scope="col">Semana</th>
                                            <th scope="col">Enviado</th>
                                            <th scope="col">Modificar</th>
                                            <th scope="col">Selección</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center" colspan="9">
                                                    <strong><?php echo e($subArea->descripcion); ?></strong>
                                                </td>
                                            </tr>
                                            <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($actividad->area_responsable == $subArea->id): ?>
                                                    <tr>
                                                        <td width="100px"><?php echo e($actividad->fecha); ?></td>
                                                        <td><?php echo e($actividad->asunto); ?></td>
                                                        <td><?php echo e($actividad->actividad); ?></td>
                                                        <td><?php echo e($actividad->status); ?></td>
                                                        <td><?php echo e($actividad->observaciones); ?></td>
                                                        <td width="40px"><?php echo e($actividad->semana); ?></td>
                                                        <td width="40px">
                                                            <?php if($actividad->fecha_vToBueno == null): ?>
                                                                NO
                                                            <?php else: ?>
                                                                SI
                                                            <?php endif; ?>
                                                        </td>
                                                        <td width="50px">
                                                            <?php if($actividad->fecha_vToBueno == null): ?>
                                                                

                                                                
                                                                <button onclick="showModal(<?php echo e($actividad); ?>)" type="button" class="btn btn-primary" 
                                                                data-toggle="modal" data-target="#modalModify">Modificar</button>
                                                            <?php else: ?>
                                                                No Disponible
                                                            <?php endif; ?>
                                                        </td>
                                                        <td width="30px">
                                                            <?php if($actividad->fecha_vToBueno == null): ?>
                                                                <div class="custom-control custom-checkbox d-flex justify-content-center">
                                                                    <input type="checkbox" value="<?php echo e($actividad->id); ?>"
                                                                        class="custom-control-input settings" name="actividades[]"
                                                                        id="check + <?php echo e($actividad->id); ?>">
                                                                    <label class="custom-control-label"
                                                                        for="check + <?php echo e($actividad->id); ?>"></label>
                                                                </div>
                                                            <?php else: ?>
                                                                No Disponible
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                                <?php if(!$actividades->isEmpty()): ?>
                                    <div class="row">
                                        <div class="col d-flex justify-content-end">
                                            <button type="submit" class="btn btn-primary">Enviar a Validación</button>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </form>
                        <?php else: ?>
                            <div class="row mt-5">
                                <div class="col text-center">
                                    <h4>Sin Actividades Registradas</h4>
                                </div>
                            </div>
                        <?php endif; ?>

                        
                    </div>
                </div>
            </div>
        </div>

        
        <div id="modalModify" class="modal fade" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    
                    <form action="<?php echo e(route('vtoBueno.editar')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Modificación de actividad</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <input class="d-none" type="text" id="id" name="id">
                            <div class="form-group col">
                                <label for="asunto" class="control-label">Asunto</label>
                                <textarea name="asunto" id="asunto" class="form-control" placeholder="Asunto" cols="30" rows="2"></textarea>
                            </div>
                            <div class="form-group col">
                                <label for="actividad" class="control-label">Actividad</label>
                                <textarea name="actividad" id="actividad" class="form-control" placeholder="Actividad" cols="30" rows="2"></textarea>
                            </div>
                            <div class="form-group col">
                                <label for="observaciones" class="control-label">Observaciones</label>
                                <textarea class="form-control" name="observaciones" id="observaciones" cols="30" rows="2" placeholder="Observaciones"></textarea>
                            </div>
                            <div class="form-group col">
                                <label for="semanaF" class="control-label">Semana</label>
                                <input type="number" class="form-control" id="semanaF" name="semanaF" placeholder="Semana">
                            </div>
                            <div class="form-group col">
                                <label for="status" class="control-label">Estado</label>
                                <select name="status" class="form-control" id="status">
                                    <option value="INICIADO">INICIADO</option>
                                    <option value="EN PROCESO">EN PROCESO</option>
                                    <option value="TERMINADO">TERMINADO</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Modificar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>

        function showModal(actividad) {
            $('#id').val(actividad['id']);
            $('#asunto').val(actividad['asunto']);
            $('#actividad').val(actividad['actividad']);
            $('#observaciones').val(actividad['observaciones']);
            $('#semanaF').val(actividad['semana']);
            $('#status').val(actividad['status']);
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\actividades\resources\views/layouts/inicioVtoBueno.blade.php ENDPATH**/ ?>